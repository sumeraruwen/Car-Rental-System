package lk.ijse.spring.repo;

import lk.ijse.spring.entity.NewAdmin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NewAdminRepo extends JpaRepository<NewAdmin,String> {

      //  NewAdmin findNewAdminById(String Id);
}
